<!DOCTYPE html>
<html class='v2' dir='ltr' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
<meta content='IE=EmulateIE7' http-equiv='X-UA-Compatible'/>
<meta content='width=1100' name='viewport'/>
<title>Live Stream Facebook - KhariDz.Me</title>
<meta charset='UTF-8'/>
<meta content='KhariDz.Systems - Live Stream Faceook Video trên máy tính của bạn cực đơn giản và nhanh chóng. Thất tuyệt với với website livefb.kharidz.me' name='description'/>
<meta content='http://livefb.kharidz.me//restserver.php' property='og:url'/>
<meta content='http://livefb.kharidz.me/favicon.ico' property='og:image'/>
<meta content='Live Stream Facebook' property='og:site_name'/>
<meta content='275898412807834' property='fb:app_id'/>
<meta content='100004787801918' property='fb:admins'/>
<meta content='en_US' property='og:locale'/>
<meta content='en_GB' property='og:locale:alternate'/>
<meta content='id_ID' property='og:locale:alternate'/>
<meta content='summary' name='twitter:card'/>
<meta content='Nguyễn Khải IT' name='twitter:title'/>
<meta content='@KhariWalkaz' name='twitter:site'/>
<meta content='@KhariWalkaz' name='twitter:creator'/>
<link href='//fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'/>
<link href='//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css' media='screen' rel='stylesheet'/>
<link href='//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css' rel='stylesheet'/>
<link href='https://botex-viet.com/assets/plugins/toastr/toastr.min.css' rel='stylesheet' type='text/css'/>
<link type='text/css' rel='stylesheet' href='https://www.blogger.com/static/v1/widgets/178992763-css_bundle_v2.css'/>
<style id='page-skin-1' type='text/css'><!--
#footer-bg{margin:0 auto;width:1150px}#footer{font-size:90%;margin:0 auto;padding:7px;background-color:#2c3e50;color:#FFF;margin-bottom:10px}
--></style>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '275898412807834',
      xfbml      : true,
      version    : 'v2.8'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<script type="text/javascript">function a(){var b=window.location.href,c=b.split("?");switch(c.length){case 1:return b+"?m=1";case 2:return 0<=c[1].search("(^|&)m=")?null:b+"&m=1";default:return null}}var d=navigator.userAgent;if(-1!=d.indexOf("Mobile")&&-1!=d.indexOf("WebKit")&&-1==d.indexOf("iPad")||-1!=d.indexOf("Opera Mini")||-1!=d.indexOf("IEMobile")){var e=a();e&&window.location.replace(e)};
</script></head>
<body><div class='fb-quote'></div>
<div class='container'>
<div class='navbar navbar-default navbar-fixed-top'>
<div class='container'>
<div class='navbar-header'>
<a class='navbar-brand' href='../'>KhariDz.Systems</a>
<button class='navbar-toggle' data-target='#navbar-main' data-toggle='collapse' type='button'>
<span class='icon-bar'></span>
<span class='icon-bar'></span>
<span class='icon-bar'></span>
</button>
</div>
<div class='navbar-collapse collapse' id='navbar-main'>
<ul class='nav navbar-nav'>
<li>
<a href='/'>Trang Chủ</a>
</li>
<li class='dropdown'>
<a class='dropdown-toggle' data-toggle='dropdown' href='#' id='themes'>Support<span class='caret'></span></a>
<ul aria-labelledby='themes' class='dropdown-menu'>
<li><a href='https://www.facebook.com/KhariWalkaz.Net' target='_blank '>Admin</a></li>
</ul>
</li>
</ul>
</div>
</div>
</div>
 
</div>
 
<div class='container'>
<div class='page-header' id='banner'>
<div class='row'><li class='divider'></li></div>
<div class='row'><div class='alert alert-dismissible alert-info'>
<button class='close' data-dismiss='alert' type='button'>X</button>
<h4>Warning!</h4>
<p>UNINSTALL Adblock, because if you install it "Go Live" button will not work</p>
</div></div></div>
<div class='center'>
<center><div class='page-header' id='banner'>
<img height='210' src='//KhariDz.Systems/images/logo.png' width='300'/>
<h1>KhariDz.Systems</h1>
<p class='lead'>Live Video Facebook trên PC</p>
</div>
<div class='fb-like' data-share='true' data-show-faces='true' data-width='450'>
</div></center></div>
<div class='container'>
<a class='btn btn-primary btn-lg btn-block' id='livevideo'>Create Live Video</a>
</div>
<script>
document.getElementById('livevideo').onclick = function() {
  FB.ui({
    display: 'popup',
    method: 'live_broadcast',
    phase: 'create',
}, function(response) {
    if (!response.id) {
      toastr.error('Thông Báo!', 'Bạn Đã Hủy Live Strems!');
      return;
    }
    /*alert('stream url:' + response.secure_stream_url);*/
    FB.ui({
      display: 'popup',
      method: 'live_broadcast',
      phase: 'publish',
      broadcast_data: response,
    }, function(response) {
      toastr.success('Thông Báo Cài Đặt!', 'Trạng Thái Streams: + response.status!');
    });
  });
};
</script>
<div class='row'></div>
<div>
<center>
<h2>OSB Download</h2>
<div class='btn-group btn-group-justified'>
<a class='btn btn-info btn-default' href='https://github.com/jp9000/obs-studio/releases/download/0.14.2/OBS-Studio-0.14.2-Installer.exe'>Cho Windows</a>
<a class='btn btn-info btn-default' href='https://github.com/jp9000/obs-studio/releases/download/0.14.2/obs-0.14.2-installer.dmg'>Cho Mac OS X</a>
<a class='btn btn-info btn-default' href='https://obsproject.com/download#linux'>Cho Linux</a>
</div><br/><h3>Mọi Thắc Mắc Xin CỜ MỜ TỜ Xuống Đây :3</h3>
<div class='fb-comments' data-href='http://livefb.kharidz.me/' data-numposts='8'></div>
</center>
</div>
</div>
 
 
<div class='footer-wid no-items section' id='footer-1'></div>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js' type='text/javascript'></script>
<script src='http://code.jquery.com/jquery-2.1.4.min.js' type='text/javascript'></script>
<script src='//KhariDz.Systems/js/bootstrap.min.js'></script>
<script src='//KhariDz.Systems/js/custom.js'></script>
<script src='https://botex-viet.com/assets/plugins/toastr/toastr.min.js'></script>
<script src='https://botex-viet.com/assets/js/pages/dashboard.js'></script>
<div id='footer-bg'>
<footer id='footer'>
Copyright &#169; 2015-<script type='text/javascript'>var creditsyear = new Date();document.write(creditsyear.getFullYear());</script>
<a href='http://livefb.kharidz.me/' itemprop='url'>Live Stream Facebook</a> | All Right Reserved<span style='float:right;'><i class='fa fa-user'></i>
<a href='//fb.com/KhariWalkaz.Net' title='About Me'>About</a> / <i class='fa fa-list'></i>
<a href='/sitemap.xml' title='Site map'>Sitemap</a> / <i class='fa fa-envelope'></i>
<a href='//fb.com/KhariWalkaz.Net' title='Contact'>Contact</a> / <a href='/' title='Author'><i class='fa fa-google-plus'></i></a></span><br/>
Design by <a href='http://www.khari-official.net' id='kharidz' rel='nofollow' target='_blank'>Nguyễn Khải</a>
</footer>
<script src='https://botex-viet.com/assets/master.js' type='text/javascript'></script>
<div class='smoothscroll-top'><span class='scroll-top-inner'><i class='fa fa-chevron-up'></i></span></div>
<script type='text/javascript'>
function r(f){/in/.test(document.readyState)?setTimeout('r('+f+')',9):f()}; r(function(){new ConversionsBox("B%E1%BA%A5m%20Th%C3%ADch%20%C4%90%E1%BB%83%20Gi%C3%BAp%20Website%20Ph%C3%A1t%20Tri%E1%BB%83n%3A","https://www.facebook.com/BotExViet");});</script>
<script>$(window).load(function(){if(""==""){$('#pages').modal('show');}});</script>
</div>
<script type="text/javascript" src="https://www.blogger.com/static/v1/widgets/803954089-widgets.js"></script>
<script type='text/javascript'>
window['__wavt'] = 'AOuZoY42viNDBAsvr0UBXbzMFrgs2TywTw:1482767573914';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d757852351523590590','//livefb.kharidz.me//restserver.php','757852351523590590');
_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '757852351523590590', 'bloggerUrl': 'https://www.blogger.com', 'title': 'Live Stream Facebook', 'pageType': 'error_page', 'url': 'http://livefb.kharidz.me//restserver.php', 'canonicalUrl': 'http://livefb.kharidz.me//restserver.php', 'homepageUrl': 'http://livefb.kharidz.me/', 'searchUrl': 'http://livefb.kharidz.me/search', 'canonicalHomepageUrl': 'http://livefb.kharidz.me/', 'blogspotFaviconUrl': 'http://livefb.kharidz.me/favicon.ico', 'hasCustomDomain': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'useUniversalAnalytics': false, 'pageName': '', 'pageTitle': 'Live Stream Facebook', 'metaDescription': 'KhariDz.Systems - Live Stream Faceook Video trên máy tính của bạn cực đơn giản và nhanh chóng.', 'encoding': 'UTF-8', 'locale': 'vi', 'localeUnderscoreDelimited': 'vi', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'languageDirection': 'ltr', 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Live Stream Facebook - Atom\x22 href\x3d\x22http://livefb.kharidz.me/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22Live Stream Facebook - RSS\x22 href\x3d\x22http://livefb.kharidz.me/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22Live Stream Facebook - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/757852351523590590/posts/default\x22 /\x3e\n', 'meTag': '', 'openIdOpTag': '', 'mobileHeadScript': '', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'ieCssRetrofitLinks': '\x3c!--[if IE]\x3e\x3cscript type\x3d\x22text/javascript\x22 src\x3d\x22https://www.blogger.com/static/v1/jsbin/3032875878-ieretrofit.js\x22\x3e\x3c/script\x3e\n\x3c![endif]--\x3e', 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/0d81398a922284ce', 'plusOneApiSrc': 'https://apis.google.com/js/plusone.js', 'sharing': {'platforms': [{'name': 'Nhận liên kết', 'key': 'link', 'shareMessage': 'Nhận liên kết', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'Chia sẻ với Facebook', 'target': 'facebook'}, {'name': 'BlogThis!', 'key': 'blogThis', 'shareMessage': 'BlogThis!', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'Chia sẻ với Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'Chia sẻ với Pinterest', 'target': 'pinterest'}, {'name': 'Google+', 'key': 'googlePlus', 'shareMessage': 'Chia sẻ với Google+', 'target': 'googleplus'}, {'name': 'Email', 'key': 'email', 'shareMessage': 'Email', 'target': 'email'}], 'googlePlusShareButtonWidth': 300, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27vi\x27};\x3c/script\x3e'}}}, {'name': 'features', 'data': {'widgetVisibility': true}}, {'name': 'messages', 'data': {'linkCopiedToClipboard': 'Đã sao chép liên kết vào khay nhớ tạm!', 'postLink': 'Liên kết bài đăng'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'Tùy chỉnh', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'Live Stream Facebook', 'description': 'KhariDz.Systems - Live Stream Faceook Video trên máy tính của bạn cực đơn giản và nhanh chóng.', 'url': 'http://livefb.kharidz.me//restserver.php', 'type': 'error', 'isSingleItem': false, 'isMultipleItems': false, 'isError': true, 'isPage': false, 'isPost': false, 'isHomepage': false, 'isArchive': false, 'isSearch': false, 'isLabelSearch': false}}]);
</script>
</body>
</html>